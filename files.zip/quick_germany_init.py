#!/usr/bin/env python3
"""
Quick initialization script for German weather database with sensible defaults.
"""

from germany_weather_db_initializer import GermanyWeatherDBInitializer
from datetime import datetime, timedelta
import sys

def quick_init():
    """Quick initialization with common settings."""
    
    print("=== Quick German Weather Database Initialization ===")
    print()
    
    # Get API key
    api_key = input("Enter your WeatherAPI.com API key: ").strip()
    if not api_key:
        print("API key is required!")
        sys.exit(1)
    
    # Choose time period
    print("\nChoose initialization period:")
    print("1. Last 3 months")
    print("2. Last 6 months") 
    print("3. Last year")
    print("4. Custom date range")
    
    choice = input("Enter choice (1-4): ").strip()
    
    today = datetime.now()
    
    if choice == "1":
        start_date = (today - timedelta(days=90)).strftime('%Y-%m-%d')
        end_date = (today - timedelta(days=1)).strftime('%Y-%m-%d')
    elif choice == "2":
        start_date = (today - timedelta(days=180)).strftime('%Y-%m-%d')
        end_date = (today - timedelta(days=1)).strftime('%Y-%m-%d')
    elif choice == "3":
        start_date = (today - timedelta(days=365)).strftime('%Y-%m-%d')
        end_date = (today - timedelta(days=1)).strftime('%Y-%m-%d')
    elif choice == "4":
        start_date = input("Enter start date (YYYY-MM-DD): ").strip()
        end_date = input("Enter end date (YYYY-MM-DD): ").strip()
    else:
        print("Invalid choice!")
        sys.exit(1)
    
    # Choose cities
    print("\nChoose cities to initialize:")
    print("1. Priority cities only (4 cities >1M population + state capitals)")
    print("2. All major cities (50+ cities)")
    
    city_choice = input("Enter choice (1-2): ").strip()
    priority_only = city_choice == "1"
    
    # Initialize
    print(f"\nInitializing database with:")
    print(f"  Date range: {start_date} to {end_date}")
    print(f"  Cities: {'Priority only' if priority_only else 'All major cities'}")
    
    confirm = input("\nProceed? (y/N): ")
    if confirm.lower() != 'y':
        print("Cancelled.")
        return
    
    # Run initialization
    initializer = GermanyWeatherDBInitializer(api_key)
    
    try:
        results = initializer.initialize_database(
            start_date, end_date,
            priority_only=priority_only,
            delay_between_calls=1.0
        )
        
        initializer.print_summary(results)
        
    except KeyboardInterrupt:
        print("\nInitialization interrupted.")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == '__main__':
    quick_init()