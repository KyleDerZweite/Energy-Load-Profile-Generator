# Additional device configurations for different use cases

DEVICE_CONFIGURATIONS = {
    # Industrial cooling system
    'industrial_cooler': {
        'base_power': 15000,  # 15kW
        'temp_coefficient': 200,  # High sensitivity to temperature
        'comfort_temp': 20,
        'daily_pattern': [0.8, 0.7, 0.7, 0.7, 0.8, 0.9, 1.0, 1.0, 1.0, 1.1, 1.2, 1.3, 1.3, 1.2, 1.1, 1.0, 1.0, 0.9, 0.9, 0.8, 0.8, 0.8, 0.8, 0.8],
        'seasonal_factor': [0.6, 0.7, 0.8, 1.0, 1.2, 1.4, 1.5, 1.4, 1.2, 1.0, 0.8, 0.7]
    },
    
    # Electric vehicle charging station
    'ev_charger': {
        'base_power': 7200,  # 7.2kW
        'temp_coefficient': 10,  # Slight temperature dependency
        'comfort_temp': 20,
        'daily_pattern': [0.3, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4, 0.6, 0.5, 0.4, 0.4, 0.5, 0.6, 0.6, 0.5, 0.6, 0.8, 1.2, 1.4, 1.3, 1.0, 0.8, 0.6, 0.4],
        'seasonal_factor': 1.0
    },
    
    # Data center cooling
    'datacenter_cooling': {
        'base_power': 25000,  # 25kW
        'temp_coefficient': 150,
        'comfort_temp': 18,
        'daily_pattern': [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
        'seasonal_factor': [0.8, 0.8, 0.9, 1.0, 1.1, 1.3, 1.4, 1.3, 1.2, 1.0, 0.9, 0.8]
    },
    
    # Greenhouse heating
    'greenhouse_heater': {
        'base_power': 5000,
        'temp_coefficient': -120,
        'comfort_temp': 16,
        'daily_pattern': [1.2, 1.1, 1.0, 0.9, 0.8, 0.8, 0.7, 0.6, 0.5, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.4, 1.3, 1.3, 1.2, 1.2],
        'seasonal_factor': [1.8, 1.6, 1.4, 1.2, 1.0, 0.8, 0.7, 0.8, 1.0, 1.2, 1.5, 1.7]
    }
}

# Example usage with different scenarios
def create_residential_scenario():
    """Typical residential energy profile"""
    return {
        'devices': ['heater', 'air_conditioner', 'general_load'],
        'quantities': {'heater': 1, 'air_conditioner': 1, 'general_load': 1}
    }

def create_commercial_scenario():
    """Commercial building energy profile"""
    return {
        'devices': ['heater', 'air_conditioner', 'general_load', 'refrigeration'],
        'quantities': {'heater': 3, 'air_conditioner': 2, 'general_load': 5, 'refrigeration': 2}
    }

def create_industrial_scenario():
    """Industrial facility energy profile"""
    return {
        'devices': ['industrial_cooler', 'general_load', 'datacenter_cooling'],
        'quantities': {'industrial_cooler': 2, 'general_load': 10, 'datacenter_cooling': 1}
    }