#!/usr/bin/env python3
"""
Script to initialize weather database with historical data for major German cities.
Covers all federal states with at least one major city, and includes all cities with >1M population.
"""

import sys
import time
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import argparse
from enhanced_energy_load_profile_generator import EnhancedEnergyLoadProfileGenerator
from weather_database import WeatherDatabase

class GermanyWeatherDBInitializer:
    """Initialize weather database with historical data for major German cities."""
    
    def __init__(self, weather_api_key: str, db_path: str = "germany_weather.db"):
        """
        Initialize the database initializer.
        
        Args:
            weather_api_key: WeatherAPI.com API key
            db_path: Path to the weather database
        """
        self.generator = EnhancedEnergyLoadProfileGenerator(weather_api_key, db_path)
        self.weather_db = WeatherDatabase(db_path)
        
        # Major German cities organized by federal state
        # Format: 'City, State' or coordinates for better API accuracy
        self.german_cities = {
            # Baden-Württemberg (Southwest)
            'Baden-Württemberg': [
                'Stuttgart, Germany',
                'Mannheim, Germany',
                'Karlsruhe, Germany',
                'Freiburg im Breisgau, Germany',
                'Heidelberg, Germany'
            ],
            
            # Bayern (Bavaria) - Southeast
            'Bayern': [
                'München, Germany',  # Munich (>1M)
                'Nürnberg, Germany',  # Nuremberg
                'Augsburg, Germany',
                'Würzburg, Germany',
                'Regensburg, Germany'
            ],
            
            # Berlin - City-state (>3M)
            'Berlin': [
                'Berlin, Germany'
            ],
            
            # Brandenburg - Surrounds Berlin
            'Brandenburg': [
                'Potsdam, Germany',
                'Cottbus, Germany'
            ],
            
            # Bremen - City-state (North)
            'Bremen': [
                'Bremen, Germany',
                'Bremerhaven, Germany'
            ],
            
            # Hamburg - City-state (North, >1M)
            'Hamburg': [
                'Hamburg, Germany'
            ],
            
            # Hessen (Hesse) - Central
            'Hessen': [
                'Frankfurt am Main, Germany',
                'Wiesbaden, Germany',
                'Kassel, Germany',
                'Darmstadt, Germany'
            ],
            
            # Mecklenburg-Vorpommern - Northeast coast
            'Mecklenburg-Vorpommern': [
                'Rostock, Germany',
                'Schwerin, Germany'
            ],
            
            # Niedersachsen (Lower Saxony) - Northwest
            'Niedersachsen': [
                'Hannover, Germany',
                'Braunschweig, Germany',  # Brunswick
                'Oldenburg, Germany',
                'Osnabrück, Germany',
                'Göttingen, Germany'
            ],
            
            # Nordrhein-Westfalen (North Rhine-Westphalia) - West (most populous state)
            'Nordrhein-Westfalen': [
                'Köln, Germany',  # Cologne (>1M)
                'Düsseldorf, Germany',
                'Dortmund, Germany',
                'Essen, Germany',
                'Duisburg, Germany',
                'Bochum, Germany',
                'Wuppertal, Germany',
                'Bielefeld, Germany',
                'Bonn, Germany',
                'Münster, Germany',
                'Mönchengladbach, Germany',
                'Gelsenkirchen, Germany',
                'Aachen, Germany'
            ],
            
            # Rheinland-Pfalz (Rhineland-Palatinate) - Southwest
            'Rheinland-Pfalz': [
                'Mainz, Germany',
                'Ludwigshafen, Germany',
                'Koblenz, Germany',
                'Trier, Germany'
            ],
            
            # Saarland - Southwest (smallest state)
            'Saarland': [
                'Saarbrücken, Germany'
            ],
            
            # Sachsen (Saxony) - East
            'Sachsen': [
                'Dresden, Germany',
                'Leipzig, Germany',
                'Chemnitz, Germany'
            ],
            
            # Sachsen-Anhalt - Central East
            'Sachsen-Anhalt': [
                'Magdeburg, Germany',
                'Halle (Saale), Germany'
            ],
            
            # Schleswig-Holstein - North (between seas)
            'Schleswig-Holstein': [
                'Kiel, Germany',
                'Lübeck, Germany'
            ],
            
            # Thüringen (Thuringia) - Central
            'Thüringen': [
                'Erfurt, Germany',
                'Jena, Germany',
                'Gera, Germany'
            ]
        }
        
        # Cities with population over 1 million (as of 2024)
        self.million_plus_cities = {
            'Berlin, Germany': 3426354,
            'Hamburg, Germany': 1906411,
            'München, Germany': 1512491,  # Munich
            'Köln, Germany': 1073096     # Cologne
        }
    
    def get_all_cities(self) -> List[str]:
        """Get flat list of all cities."""
        all_cities = []
        for state, cities in self.german_cities.items():
            all_cities.extend(cities)
        return list(set(all_cities))  # Remove duplicates
    
    def get_priority_cities(self) -> List[str]:
        """Get priority cities (1M+ population and state capitals)."""
        priority_cities = list(self.million_plus_cities.keys())
        
        # Add state capitals and major cities
        additional_priority = [
            'Stuttgart, Germany',  # Baden-Württemberg capital
            'Dresden, Germany',    # Saxony capital
            'Düsseldorf, Germany', # NRW capital
            'Erfurt, Germany',     # Thuringia capital
            'Hannover, Germany',   # Lower Saxony capital
            'Kiel, Germany',       # Schleswig-Holstein capital
            'Magdeburg, Germany',  # Saxony-Anhalt capital
            'Mainz, Germany',      # Rhineland-Palatinate capital
            'Potsdam, Germany',    # Brandenburg capital
            'Saarbrücken, Germany', # Saarland capital
            'Schwerin, Germany',   # Mecklenburg-Vorpommern capital
            'Wiesbaden, Germany',  # Hesse capital
            'Frankfurt am Main, Germany'  # Financial center
        ]
        
        priority_cities.extend(additional_priority)
        return list(set(priority_cities))
    
    def initialize_database(self, start_date: str, end_date: str, 
                          priority_only: bool = False, 
                          delay_between_calls: float = 1.0,
                          max_retries: int = 3) -> Dict[str, str]:
        """
        Initialize the database with historical weather data.
        
        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            priority_only: If True, only fetch priority cities
            delay_between_calls: Delay in seconds between API calls
            max_retries: Maximum number of retries for failed requests
        
        Returns:
            Dictionary with results for each city
        """
        cities_to_fetch = self.get_priority_cities() if priority_only else self.get_all_cities()
        
        print(f"Initializing weather database for {len(cities_to_fetch)} German cities")
        print(f"Date range: {start_date} to {end_date}")
        print(f"Priority only: {priority_only}")
        print(f"Delay between calls: {delay_between_calls}s")
        print("=" * 60)
        
        results = {}
        total_cities = len(cities_to_fetch)
        
        for i, city in enumerate(cities_to_fetch, 1):
            print(f"\n[{i}/{total_cities}] Processing {city}...")
            
            # Check if data already exists
            availability = self.weather_db.check_data_availability(city, start_date, end_date)
            
            if availability['location_exists'] and availability['coverage'] > 0.95:
                print(f"  ✓ Data already exists (Coverage: {availability['coverage']:.1%})")
                results[city] = "Already exists"
                continue
            
            # Fetch data with retries
            success = False
            for attempt in range(max_retries):
                try:
                    print(f"  Fetching data (attempt {attempt + 1}/{max_retries})...")
                    weather_data = self.generator.get_weather_data(
                        city, start_date, end_date, force_api_call=True
                    )
                    
                    if not weather_data.empty:
                        print(f"  ✓ Successfully fetched {len(weather_data)} records")
                        results[city] = f"Success ({len(weather_data)} records)"
                        success = True
                        break
                    else:
                        print(f"  ⚠ Empty data received")
                        
                except Exception as e:
                    print(f"  ✗ Error on attempt {attempt + 1}: {str(e)}")
                    if attempt < max_retries - 1:
                        print(f"    Retrying in {delay_between_calls * 2}s...")
                        time.sleep(delay_between_calls * 2)
            
            if not success:
                results[city] = "Failed after retries"
                print(f"  ✗ Failed to fetch data after {max_retries} attempts")
            
            # Delay between cities to be respectful to API
            if i < total_cities:
                print(f"  Waiting {delay_between_calls}s before next city...")
                time.sleep(delay_between_calls)
        
        return results
    
    def print_summary(self, results: Dict[str, str]):
        """Print a summary of the initialization results."""
        print("\n" + "=" * 60)
        print("INITIALIZATION SUMMARY")
        print("=" * 60)
        
        success_count = sum(1 for status in results.values() if status.startswith("Success"))
        already_exists_count = sum(1 for status in results.values() if status == "Already exists")
        failed_count = sum(1 for status in results.values() if status.startswith("Failed"))
        
        print(f"Total cities processed: {len(results)}")
        print(f"Successfully fetched: {success_count}")
        print(f"Already existed: {already_exists_count}")
        print(f"Failed: {failed_count}")
        
        if failed_count > 0:
            print(f"\nFailed cities:")
            for city, status in results.items():
                if status.startswith("Failed"):
                    print(f"  - {city}")
        
        # Database statistics
        stats = self.weather_db.get_database_stats()
        print(f"\nDatabase Statistics:")
        print(f"  Total records: {stats['total_weather_records']:,}")
        print(f"  Total locations: {stats['total_locations']}")
        print(f"  Database size: {stats['database_size_mb']:.2f} MB")
        
        if stats['earliest_date'] and stats['latest_date']:
            print(f"  Date range: {stats['earliest_date']} to {stats['latest_date']}")
    
    def show_cities_by_state(self):
        """Display all cities organized by federal state."""
        print("German Cities by Federal State")
        print("=" * 60)
        
        for state, cities in self.german_cities.items():
            print(f"\n{state} ({len(cities)} cities):")
            for city in cities:
                # Mark million+ cities
                marker = " (>1M)" if city in self.million_plus_cities else ""
                print(f"  - {city}{marker}")
    
    def validate_date_range(self, start_date: str, end_date: str) -> bool:
        """Validate the date range."""
        try:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
            
            if start_dt >= end_dt:
                print("Error: Start date must be before end date")
                return False
            
            if end_dt > datetime.now():
                print("Error: End date cannot be in the future")
                return False
            
            # Check if range is too large (more than 2 years)
            if (end_dt - start_dt).days > 730:
                print("Warning: Date range is more than 2 years. This will take a long time and many API calls.")
                confirm = input("Continue anyway? (y/N): ")
                return confirm.lower() == 'y'
            
            return True
            
        except ValueError:
            print("Error: Invalid date format. Use YYYY-MM-DD")
            return False

def main():
    parser = argparse.ArgumentParser(
        description='Initialize weather database with historical data for major German cities'
    )
    parser.add_argument('--api-key', required=True, 
                       help='WeatherAPI.com API key')
    parser.add_argument('--db-path', default='germany_weather.db',
                       help='Database file path')
    parser.add_argument('--start-date', required=True,
                       help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end-date', required=True,
                       help='End date (YYYY-MM-DD)')
    parser.add_argument('--priority-only', action='store_true',
                       help='Only fetch priority cities (capitals and 1M+ population)')
    parser.add_argument('--delay', type=float, default=1.0,
                       help='Delay between API calls in seconds (default: 1.0)')
    parser.add_argument('--max-retries', type=int, default=3,
                       help='Maximum retries for failed requests (default: 3)')
    parser.add_argument('--show-cities', action='store_true',
                       help='Show all cities and exit')
    parser.add_argument('--dry-run', action='store_true',
                       help='Show what would be done without actually doing it')
    
    args = parser.parse_args()
    
    # Initialize the database initializer
    initializer = GermanyWeatherDBInitializer(args.api_key, args.db_path)
    
    if args.show_cities:
        initializer.show_cities_by_state()
        return
    
    # Validate date range
    if not initializer.validate_date_range(args.start_date, args.end_date):
        sys.exit(1)
    
    if args.dry_run:
        cities_to_fetch = (initializer.get_priority_cities() if args.priority_only 
                          else initializer.get_all_cities())
        print(f"DRY RUN: Would fetch data for {len(cities_to_fetch)} cities:")
        for city in cities_to_fetch:
            print(f"  - {city}")
        return
    
    # Confirm before starting
    cities_to_fetch = (initializer.get_priority_cities() if args.priority_only 
                      else initializer.get_all_cities())
    
    print(f"About to fetch weather data for {len(cities_to_fetch)} German cities")
    print(f"Date range: {args.start_date} to {args.end_date}")
    print(f"This will make approximately {len(cities_to_fetch) * ((datetime.strptime(args.end_date, '%Y-%m-%d') - datetime.strptime(args.start_date, '%Y-%m-%d')).days + 1)} API calls")
    
    confirm = input("Continue? (y/N): ")
    if confirm.lower() != 'y':
        print("Initialization cancelled.")
        return
    
    # Start initialization
    start_time = time.time()
    
    try:
        results = initializer.initialize_database(
            args.start_date, args.end_date,
            priority_only=args.priority_only,
            delay_between_calls=args.delay,
            max_retries=args.max_retries
        )
        
        # Print summary
        initializer.print_summary(results)
        
        end_time = time.time()
        duration = end_time - start_time
        print(f"\nTotal execution time: {duration:.1f} seconds ({duration/60:.1f} minutes)")
        
    except KeyboardInterrupt:
        print("\n\nInitialization interrupted by user")
        print("Partial data may have been saved to the database")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()