import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import time
import json
from weather_database import WeatherDatabase

class MultiSourceWeatherDatabase(WeatherDatabase):
    """Enhanced weather database supporting multiple long-term historical data sources."""
    
    def __init__(self, db_path: str = "multi_source_weather.db"):
        super().__init__(db_path)
        self.init_extended_tables()
    
    def init_extended_tables(self):
        """Create additional tables for tracking data sources."""
        with sqlite3.connect(self.db_path) as conn:
            # Add source tracking to weather_data table
            try:
                conn.execute('ALTER TABLE weather_data ADD COLUMN data_source TEXT DEFAULT "unknown"')
            except:
                pass  # Column might already exist
            
            # Create data sources table
            conn.execute('''
                CREATE TABLE IF NOT EXISTS data_sources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_name TEXT UNIQUE NOT NULL,
                    api_url TEXT,
                    description TEXT,
                    date_range_start TEXT,
                    date_range_end TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    last_used TEXT
                )
            ''')
            
            # Insert known data sources
            sources = [
                ('open_meteo', 'https://archive-api.open-meteo.com/v1/era5', 
                 'Open-Meteo ERA5 Reanalysis (1940-present)', '1940-01-01', '2024-12-31'),
                ('dwd_cdc', 'https://opendata.dwd.de/climate_environment/CDC/', 
                 'German Weather Service Climate Data Center', '1881-01-01', '2024-12-31'),
                ('weatherapi', 'http://api.weatherapi.com/v1', 
                 'WeatherAPI.com (1 year limit)', '2023-01-01', '2024-12-31'),
                ('noaa_cdo', 'https://www.ncei.noaa.gov/cdo-web/api/v2/', 
                 'NOAA Climate Data Online', '1750-01-01', '2024-12-31')
            ]
            
            for source in sources:
                conn.execute('''
                    INSERT OR IGNORE INTO data_sources 
                    (source_name, api_url, description, date_range_start, date_range_end)
                    VALUES (?, ?, ?, ?, ?)
                ''', source)

class LongTermWeatherFetcher:
    """Fetcher for long-term historical weather data from multiple sources."""
    
    def __init__(self, db_path: str = "multi_source_weather.db"):
        self.db = MultiSourceWeatherDatabase(db_path)
        
    def fetch_open_meteo_data(self, latitude: float, longitude: float, 
                             start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch historical weather data from Open-Meteo ERA5 (1940-present).
        
        Args:
            latitude: Latitude coordinate
            longitude: Longitude coordinate  
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
        
        Returns:
            DataFrame with weather data
        """
        base_url = "https://archive-api.open-meteo.com/v1/era5"
        
        params = {
            'latitude': latitude,
            'longitude': longitude,
            'start_date': start_date,
            'end_date': end_date,
            'hourly': 'temperature_2m,relative_humidity_2m,precipitation,weather_code',
            'timezone': 'Europe/Berlin',
            'format': 'json'
        }
        
        print(f"Fetching Open-Meteo data for coordinates ({latitude}, {longitude})...")
        
        try:
            response = requests.get(base_url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            if 'hourly' not in data:
                raise ValueError("No hourly data in response")
            
            # Parse the response
            hourly = data['hourly']
            timestamps = pd.to_datetime(hourly['time'])
            
            weather_data = []
            for i, timestamp in enumerate(timestamps):
                weather_data.append({
                    'datetime': timestamp,
                    'temperature': hourly['temperature_2m'][i],
                    'humidity': hourly['relative_humidity_2m'][i] if hourly['relative_humidity_2m'][i] else 50,
                    'precipitation': hourly['precipitation'][i] if hourly['precipitation'] else 0,
                    'weather_code': hourly['weather_code'][i] if hourly['weather_code'] else 0,
                    'condition': self._weather_code_to_condition(hourly['weather_code'][i] if hourly['weather_code'] else 0)
                })
            
            df = pd.DataFrame(weather_data)
            df.set_index('datetime', inplace=True)
            
            # Resample to 15-minute intervals
            df_15min = df.resample('15T').interpolate(method='linear')
            
            print(f"Successfully fetched {len(df_15min)} records from Open-Meteo")
            return df_15min
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching Open-Meteo data: {e}")
            return pd.DataFrame()
        except Exception as e:
            print(f"Error processing Open-Meteo data: {e}")
            return pd.DataFrame()
    
    def fetch_dwd_data(self, station_id: str, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch historical weather data from DWD Climate Data Center.
        
        Args:
            station_id: DWD station ID (e.g., "00044" for Aachen)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
        
        Returns:
            DataFrame with weather data
        """
        # Note: This is a simplified implementation
        # For production use, you'd want to implement proper DWD FTP parsing
        print(f"DWD data fetching for station {station_id} - placeholder implementation")
        print("For full DWD integration, consider using the 'rdwd' R package or direct FTP access")
        return pd.DataFrame()
    
    def _weather_code_to_condition(self, code: int) -> str:
        """Convert WMO weather code to readable condition."""
        code_map = {
            0: "Clear sky",
            1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
            45: "Fog", 48: "Depositing rime fog",
            51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
            61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
            80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
            95: "Thunderstorm", 96: "Thunderstorm with hail"
        }
        return code_map.get(code, "Unknown")
    
    def get_city_coordinates(self, city_name: str) -> Tuple[float, float]:
        """Get coordinates for a city using a simple geocoding approach."""
        # German city coordinates (major cities)
        city_coords = {
            'Berlin': (52.5200, 13.4050),
            'Hamburg': (53.5511, 9.9937),
            'München': (48.1351, 11.5820),
            'Munich': (48.1351, 11.5820),
            'Köln': (50.9375, 6.9603),
            'Cologne': (50.9375, 6.9603),
            'Frankfurt am Main': (50.1109, 8.6821),
            'Stuttgart': (48.7758, 9.1829),
            'Düsseldorf': (51.2277, 6.7735),
            'Dortmund': (51.5136, 7.4653),
            'Essen': (51.4556, 7.0116),
            'Leipzig': (51.3397, 12.3731),
            'Bremen': (53.0793, 8.8017),
            'Dresden': (51.0504, 13.7373),
            'Hannover': (52.3759, 9.7320),
            'Nürnberg': (49.4521, 11.0767),
            'Nuremberg': (49.4521, 11.0767),
            'Duisburg': (51.4344, 6.7623),
            'Bochum': (51.4819, 7.2162),
            'Wuppertal': (51.2562, 7.1508),
            'Bielefeld': (52.0302, 8.5325),
            'Bonn': (50.7374, 7.0982),
            'Münster': (51.9607, 7.6261),
            'Karlsruhe': (49.0069, 8.4037),
            'Mannheim': (49.4875, 8.4660),
            'Augsburg': (48.3705, 10.8978),
            'Wiesbaden': (50.0782, 8.2398),
            'Gelsenkirchen': (51.5177, 7.0857),
            'Mönchengladbach': (51.1805, 6.4428),
            'Braunschweig': (52.2689, 10.5268),
            'Chemnitz': (50.8279, 12.9214),
            'Kiel': (54.3233, 10.1228),
            'Aachen': (50.7753, 6.0839),
            'Halle': (51.4969, 11.9695),
            'Magdeburg': (52.1205, 11.6276),
            'Freiburg': (47.9990, 7.8421),
            'Krefeld': (51.3388, 6.5853),
            'Lübeck': (53.8654, 10.6865),
            'Mainz': (49.9929, 8.2473),
            'Erfurt': (50.9848, 11.0299),
            'Rostock': (54.0887, 12.1447),
            'Kassel': (51.3127, 9.4797),
            'Hagen': (51.3670, 7.4637),
            'Potsdam': (52.3906, 13.0645),
            'Saarbrücken': (49.2401, 6.9969),
            'Hamm': (51.6806, 7.8206),
            'Mülheim': (51.4266, 6.8781),
            'Ludwigshafen': (49.4814, 8.4451),
            'Leverkusen': (51.0459, 6.9891),
            'Oldenburg': (53.1435, 8.2146),
            'Osnabrück': (52.2799, 8.0472),
            'Solingen': (51.1651, 7.0679),
            'Heidelberg': (49.3988, 8.6724),
            'Herne': (51.5386, 7.2221),
            'Neuss': (51.1979, 6.6845),
            'Darmstadt': (49.8728, 8.6512),
            'Paderborn': (51.7189, 8.7575),
            'Regensburg': (49.0134, 12.1016),
            'Ingolstadt': (48.7665, 11.4257),
            'Würzburg': (49.7913, 9.9534),
            'Fürth': (49.4778, 10.9890),
            'Wolfsburg': (52.4227, 10.7865),
            'Offenbach': (50.0955, 8.7761),
            'Ulm': (48.4011, 9.9876),
            'Heilbronn': (49.1427, 9.2108),
            'Pforzheim': (48.8918, 8.6942),
            'Göttingen': (51.5412, 9.9158),
            'Bottrop': (51.5216, 6.9289),
            'Trier': (49.7596, 6.6441),
            'Recklinghausen': (51.6142, 7.1975),
            'Reutlingen': (48.4919, 9.2042),
            'Koblenz': (50.3569, 7.5890),
            'Remscheid': (51.1789, 7.1925),
            'Bergisch Gladbach': (50.9921, 7.1290),
            'Jena': (50.9278, 11.5896),
            'Moers': (51.4508, 6.6407),
            'Siegen': (50.8739, 8.0240),
            'Hildesheim': (52.1561, 9.9511),
            'Salzgitter': (52.1533, 10.3317),
            'Cottbus': (51.7606, 14.3346),
            'Schwerin': (53.6355, 11.4010),
            'Bremerhaven': (53.5396, 8.5805)
        }
        
        # Clean city name
        city_clean = city_name.replace(', Germany', '').strip()
        
        if city_clean in city_coords:
            return city_coords[city_clean]
        else:
            # Try approximate geocoding with a simple web service
            try:
                geocode_url = f"https://geocoding-api.open-meteo.com/v1/search"
                params = {'name': city_clean, 'count': 1, 'language': 'en', 'format': 'json'}
                response = requests.get(geocode_url, params=params, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('results'):
                        result = data['results'][0]
                        return (result['latitude'], result['longitude'])
            except:
                pass
            
            # Default to Berlin if not found
            print(f"Warning: Coordinates for {city_name} not found, using Berlin as default")
            return (52.5200, 13.4050)
    
    def fetch_long_term_data(self, location: str, start_date: str, end_date: str, 
                            preferred_source: str = 'open_meteo') -> pd.DataFrame:
        """
        Fetch long-term historical weather data using the best available source.
        
        Args:
            location: City name or coordinates
            start_date: Start date (YYYY-MM-DD) 
            end_date: End date (YYYY-MM-DD)
            preferred_source: Preferred data source ('open_meteo', 'dwd_cdc', etc.)
        
        Returns:
            DataFrame with weather data
        """
        # Check if data already exists locally
        existing_data = self.db.get_weather_data(location, start_date, end_date)
        if existing_data is not None and not existing_data.empty:
            coverage = len(existing_data) / self._calculate_expected_records(start_date, end_date)
            if coverage > 0.95:
                print(f"Using existing data for {location} (Coverage: {coverage:.1%})")
                return existing_data
        
        # Get coordinates for the location
        lat, lon = self.get_city_coordinates(location)
        print(f"Coordinates for {location}: ({lat}, {lon})")
        
        # Fetch from preferred source
        if preferred_source == 'open_meteo':
            weather_data = self.fetch_open_meteo_data(lat, lon, start_date, end_date)
        elif preferred_source == 'dwd_cdc':
            # For DWD, you'd need to find the nearest station ID
            weather_data = self.fetch_dwd_data("00044", start_date, end_date)  # Placeholder
        else:
            raise ValueError(f"Unknown data source: {preferred_source}")
        
        # Store the data if successful
        if not weather_data.empty:
            # Add source information
            weather_data['data_source'] = preferred_source
            self.db.store_weather_data(location, weather_data)
            
            # Update source usage
            with sqlite3.connect(self.db.db_path) as conn:
                conn.execute('''
                    UPDATE data_sources 
                    SET last_used = ? 
                    WHERE source_name = ?
                ''', (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), preferred_source))
        
        return weather_data
    
    def _calculate_expected_records(self, start_date: str, end_date: str) -> int:
        """Calculate expected number of 15-minute interval records."""
        start_dt = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        total_minutes = int((end_dt - start_dt).total_seconds() / 60)
        return total_minutes // 15 + 1

# Integration with existing energy load profile generator
class LongTermEnergyLoadProfileGenerator:
    """Energy load profile generator with long-term historical weather data support."""
    
    def __init__(self, db_path: str = "long_term_weather.db"):
        self.weather_fetcher = LongTermWeatherFetcher(db_path)
        
        # Device configurations (same as before)
        self.device_configs = {
            'heater': {
                'base_power': 2000,
                'temp_coefficient': -50,
                'comfort_temp': 20,
                'daily_pattern': [0.8, 0.6, 0.5, 0.4, 0.4, 0.6, 1.0, 0.9, 0.7, 0.6, 0.6, 0.7, 0.8, 0.8, 0.9, 1.0, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.8],
                'seasonal_factor': 1.0
            },
            'air_conditioner': {
                'base_power': 1500,
                'temp_coefficient': 80,
                'comfort_temp': 22,
                'daily_pattern': [0.3, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4, 0.5, 0.7, 0.9, 1.1, 1.3, 1.4, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3],
                'seasonal_factor': 1.0
            },
            'general_load': {
                'base_power': 1000,
                'temp_coefficient': 0,
                'comfort_temp': 20,
                'daily_pattern': [0.4, 0.3, 0.3, 0.3, 0.3, 0.4, 0.8, 1.0, 0.9, 0.8, 0.8, 0.9, 1.0, 0.9, 0.8, 0.9, 1.2, 1.4, 1.3, 1.1, 0.9, 0.7, 0.6, 0.5],
                'seasonal_factor': 1.0
            }
        }
    
    def get_long_term_weather_data(self, location: str, start_date: str, end_date: str) -> pd.DataFrame:
        """Get long-term weather data (supports decades of historical data)."""
        return self.weather_fetcher.fetch_long_term_data(location, start_date, end_date)
    
    def generate_multi_year_load_profile(self, devices: List[str], location: str,
                                       start_date: str, end_date: str,
                                       quantities: Optional[Dict[str, int]] = None) -> pd.DataFrame:
        """Generate load profile for multiple years of data."""
        print(f"Generating multi-year load profile for {location}")
        print(f"Date range: {start_date} to {end_date}")
        
        # Get long-term weather data
        weather_data = self.get_long_term_weather_data(location, start_date, end_date)
        
        if weather_data.empty:
            raise ValueError(f"No weather data available for {location}")
        
        # Generate load profile (same logic as before)
        if quantities is None:
            quantities = {device: 1 for device in devices}
        
        load_data = []
        
        for idx, (timestamp, row) in enumerate(weather_data.iterrows()):
            if idx % 10000 == 0:  # Progress indicator for large datasets
                print(f"Processing record {idx:,}/{len(weather_data):,}")
            
            temperature = row['temperature']
            hour_of_day = timestamp.hour
            day_of_year = timestamp.timetuple().tm_yday
            
            total_power = 0
            device_powers = {}
            
            for device in devices:
                device_quantity = quantities.get(device, 1)
                device_power = self._calculate_device_load(
                    device, temperature, hour_of_day, day_of_year
                ) * device_quantity
                
                device_powers[f'{device}_power'] = device_power
                total_power += device_power
            
            load_entry = {
                'datetime': timestamp,
                'temperature': temperature,
                'total_power': total_power,
                'hour_of_day': hour_of_day,
                'day_of_year': day_of_year
            }
            load_entry.update(device_powers)
            load_data.append(load_entry)
        
        df = pd.DataFrame(load_data)
        df.set_index('datetime', inplace=True)
        
        print(f"Generated load profile with {len(df):,} records")
        return df
    
    def _calculate_device_load(self, device_name: str, temperature: float, 
                              hour_of_day: int, day_of_year: int) -> float:
        """Calculate device load (same as original implementation)."""
        if device_name not in self.device_configs:
            raise ValueError(f"Device '{device_name}' not configured")
        
        config = self.device_configs[device_name]
        
        base_power = config['base_power']
        temp_diff = temperature - config['comfort_temp']
        temp_factor = 1 + (temp_diff * config['temp_coefficient'] / base_power)
        temp_factor = max(0.1, temp_factor)
        
        daily_factor = config['daily_pattern'][hour_of_day]
        seasonal_factor = config.get('seasonal_factor', 1.0)
        
        if isinstance(seasonal_factor, (list, tuple)):
            season_index = (day_of_year - 1) * len(seasonal_factor) / 365
            seasonal_factor = np.interp(season_index, range(len(seasonal_factor)), seasonal_factor)
        
        random_factor = 1 + np.random.normal(0, 0.05)
        total_power = base_power * temp_factor * daily_factor * seasonal_factor * random_factor
        
        return max(0, total_power)

def main():
    """Example usage with long-term data."""
    # Initialize the long-term generator
    generator = LongTermEnergyLoadProfileGenerator("long_term_weather.db")
    
    # Example: Generate load profile for 5 years (2019-2024)
    location = "Berlin, Germany"
    start_date = "2019-01-01"
    end_date = "2024-01-01"
    
    devices = ['heater', 'air_conditioner', 'general_load']
    quantities = {'heater': 2, 'air_conditioner': 1, 'general_load': 3}
    
    print("Generating 5-year energy load profile...")
    load_profile = generator.generate_multi_year_load_profile(
        devices, location, start_date, end_date, quantities
    )
    
    # Calculate yearly statistics
    load_profile['year'] = load_profile.index.year
    yearly_stats = load_profile.groupby('year').agg({
        'total_power': ['mean', 'max', 'sum'],
        'temperature': ['mean', 'min', 'max']
    }).round(2)
    
    print("\nYearly Statistics:")
    print(yearly_stats)
    
    # Export to CSV
    load_profile.to_csv('long_term_load_profile.csv')
    print("\nData exported to 'long_term_load_profile.csv'")

if __name__ == "__main__":
    main()