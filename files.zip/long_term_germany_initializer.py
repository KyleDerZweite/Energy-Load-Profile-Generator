#!/usr/bin/env python3
"""
Initialize German weather database with decades of historical data using Open-Meteo.
"""

import argparse
import sys
from datetime import datetime, timedelta
from multi_source_weather_database import LongTermWeatherFetcher

def main():
    parser = argparse.ArgumentParser(
        description='Initialize weather database with long-term historical data for German cities'
    )
    parser.add_argument('--start-year', type=int, default=2000,
                       help='Start year for data collection (default: 2000)')
    parser.add_argument('--end-year', type=int, default=2024,
                       help='End year for data collection (default: 2024)')
    parser.add_argument('--cities', nargs='+', 
                       default=['Berlin', 'Munich', 'Hamburg', 'Cologne', 'Frankfurt am Main'],
                       help='Cities to fetch data for')
    parser.add_argument('--db-path', default='long_term_germany_weather.db',
                       help='Database file path')
    parser.add_argument('--source', default='open_meteo', choices=['open_meteo', 'dwd_cdc'],
                       help='Data source to use')
    
    args = parser.parse_args()
    
    # Initialize fetcher
    fetcher = LongTermWeatherFetcher(args.db_path)
    
    start_date = f"{args.start_year}-01-01"
    end_date = f"{args.end_year}-12-31"
    
    print(f"Initializing {args.end_year - args.start_year + 1} years of weather data")
    print(f"Period: {start_date} to {end_date}")
    print(f"Cities: {', '.join(args.cities)}")
    print(f"Source: {args.source}")
    
    confirm = input("Continue? (y/N): ")
    if confirm.lower() != 'y':
        return
    
    results = {}
    
    for i, city in enumerate(args.cities, 1):
        print(f"\n[{i}/{len(args.cities)}] Processing {city}...")
        
        try:
            weather_data = fetcher.fetch_long_term_data(
                city, start_date, end_date, preferred_source=args.source
            )
            
            if not weather_data.empty:
                results[city] = f"Success ({len(weather_data):,} records)"
                print(f"✓ Successfully fetched {len(weather_data):,} records")
            else:
                results[city] = "Failed - no data"
                print("✗ No data received")
                
        except Exception as e:
            results[city] = f"Error: {str(e)}"
            print(f"✗ Error: {e}")
    
    # Print summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    
    for city, status in results.items():
        print(f"{city:<25} {status}")
    
    # Database stats
    stats = fetcher.db.get_database_stats()
    print(f"\nDatabase Statistics:")
    print(f"Total records: {stats['total_weather_records']:,}")
    print(f"Database size: {stats['database_size_mb']:.2f} MB")

if __name__ == '__main__':
    main()