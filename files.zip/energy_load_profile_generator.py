import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json
from typing import Dict, List, Optional
import math

class EnergyLoadProfileGenerator:
    """
    Generate realistic energy consumption load profiles based on temperature data
    and configurable device parameters.
    """
    
    def __init__(self, weather_api_key: str):
        """
        Initialize the load profile generator.
        
        Args:
            weather_api_key: API key for WeatherAPI.com
        """
        self.weather_api_key = weather_api_key
        self.base_url = "http://api.weatherapi.com/v1"
        
        # Default device configurations
        self.device_configs = {
            'heater': {
                'base_power': 2000,  # Watts
                'temp_coefficient': -50,  # Power increase per degree below 20°C
                'comfort_temp': 20,  # °C
                'daily_pattern': [0.8, 0.6, 0.5, 0.4, 0.4, 0.6, 1.0, 0.9, 0.7, 0.6, 0.6, 0.7, 0.8, 0.8, 0.9, 1.0, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.8],
                'seasonal_factor': 1.0
            },
            'air_conditioner': {
                'base_power': 1500,  # Watts
                'temp_coefficient': 80,  # Power increase per degree above 22°C
                'comfort_temp': 22,  # °C
                'daily_pattern': [0.3, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4, 0.5, 0.7, 0.9, 1.1, 1.3, 1.4, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3],
                'seasonal_factor': 1.0
            },
            'refrigeration': {
                'base_power': 800,  # Watts
                'temp_coefficient': 15,  # Power increase per degree above 15°C
                'comfort_temp': 15,  # °C
                'daily_pattern': [0.9, 0.8, 0.8, 0.8, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.2, 1.1, 1.0, 1.0, 1.1, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9, 0.9, 0.9, 0.9],
                'seasonal_factor': 1.0
            },
            'general_load': {
                'base_power': 1000,  # Watts
                'temp_coefficient': 0,  # No temperature dependency
                'comfort_temp': 20,  # °C
                'daily_pattern': [0.4, 0.3, 0.3, 0.3, 0.3, 0.4, 0.8, 1.0, 0.9, 0.8, 0.8, 0.9, 1.0, 0.9, 0.8, 0.9, 1.2, 1.4, 1.3, 1.1, 0.9, 0.7, 0.6, 0.5],
                'seasonal_factor': 1.0
            }
        }
    
    def get_weather_data(self, location: str, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch historical weather data from WeatherAPI.com
        
        Args:
            location: City name or coordinates (lat,lon)
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
        
        Returns:
            DataFrame with temperature data at hourly intervals
        """
        weather_data = []
        current_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        while current_date <= end_dt:
            url = f"{self.base_url}/history.json"
            params = {
                'key': self.weather_api_key,
                'q': location,
                'dt': current_date.strftime('%Y-%m-%d')
            }
            
            try:
                response = requests.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                
                for hour_data in data['forecast']['forecastday'][0]['hour']:
                    weather_data.append({
                        'datetime': pd.to_datetime(hour_data['time']),
                        'temperature': hour_data['temp_c'],
                        'humidity': hour_data['humidity'],
                        'condition': hour_data['condition']['text']
                    })
                    
            except requests.exceptions.RequestException as e:
                print(f"Error fetching weather data for {current_date}: {e}")
                # Fill with average temperature if API fails
                for hour in range(24):
                    weather_data.append({
                        'datetime': current_date.replace(hour=hour),
                        'temperature': 15.0,  # Default temperature
                        'humidity': 50,
                        'condition': 'Unknown'
                    })
            
            current_date += timedelta(days=1)
        
        df = pd.DataFrame(weather_data)
        df.set_index('datetime', inplace=True)
        
        # Interpolate to 15-minute intervals
        df_15min = df.resample('15T').interpolate(method='linear')
        
        return df_15min
    
    def add_device_config(self, device_name: str, config: Dict):
        """
        Add or update a device configuration.
        
        Args:
            device_name: Name of the device
            config: Dictionary with device parameters
        """
        required_keys = ['base_power', 'temp_coefficient', 'comfort_temp', 'daily_pattern']
        if not all(key in config for key in required_keys):
            raise ValueError(f"Device config must contain: {required_keys}")
        
        if len(config['daily_pattern']) != 24:
            raise ValueError("Daily pattern must have 24 hourly values")
        
        self.device_configs[device_name] = config
    
    def calculate_device_load(self, device_name: str, temperature: float, 
                            hour_of_day: int, day_of_year: int) -> float:
        """
        Calculate power consumption for a specific device at given conditions.
        
        Args:
            device_name: Name of the device
            temperature: Current temperature in Celsius
            hour_of_day: Hour of the day (0-23)
            day_of_year: Day of the year (1-365)
        
        Returns:
            Power consumption in Watts
        """
        if device_name not in self.device_configs:
            raise ValueError(f"Device '{device_name}' not configured")
        
        config = self.device_configs[device_name]
        
        # Base power consumption
        base_power = config['base_power']
        
        # Temperature influence
        temp_diff = temperature - config['comfort_temp']
        temp_factor = 1 + (temp_diff * config['temp_coefficient'] / base_power)
        temp_factor = max(0.1, temp_factor)  # Minimum 10% of base power
        
        # Daily pattern influence
        daily_factor = config['daily_pattern'][hour_of_day]
        
        # Seasonal influence (optional)
        seasonal_factor = config.get('seasonal_factor', 1.0)
        if isinstance(seasonal_factor, (list, tuple)):
            # If seasonal_factor is a list, interpolate based on day of year
            season_index = (day_of_year - 1) * len(seasonal_factor) / 365
            seasonal_factor = np.interp(season_index, range(len(seasonal_factor)), seasonal_factor)
        
        # Add some random variation (±5%)
        random_factor = 1 + np.random.normal(0, 0.05)
        
        total_power = base_power * temp_factor * daily_factor * seasonal_factor * random_factor
        
        return max(0, total_power)  # Ensure non-negative power
    
    def generate_load_profile(self, devices: List[str], weather_data: pd.DataFrame,
                            quantities: Optional[Dict[str, int]] = None) -> pd.DataFrame:
        """
        Generate combined load profile for multiple devices.
        
        Args:
            devices: List of device names to include
            weather_data: DataFrame with temperature data
            quantities: Dictionary specifying quantity of each device type
        
        Returns:
            DataFrame with load profile data
        """
        if quantities is None:
            quantities = {device: 1 for device in devices}
        
        load_data = []
        
        for idx, (timestamp, row) in enumerate(weather_data.iterrows()):
            temperature = row['temperature']
            hour_of_day = timestamp.hour
            day_of_year = timestamp.timetuple().tm_yday
            
            total_power = 0
            device_powers = {}
            
            for device in devices:
                device_quantity = quantities.get(device, 1)
                device_power = self.calculate_device_load(
                    device, temperature, hour_of_day, day_of_year
                ) * device_quantity
                
                device_powers[f'{device}_power'] = device_power
                total_power += device_power
            
            load_entry = {
                'datetime': timestamp,
                'temperature': temperature,
                'total_power': total_power,
                'hour_of_day': hour_of_day,
                'day_of_year': day_of_year
            }
            load_entry.update(device_powers)
            load_data.append(load_entry)
        
        df = pd.DataFrame(load_data)
        df.set_index('datetime', inplace=True)
        
        return df
    
    def plot_load_profile(self, load_data: pd.DataFrame, days_to_plot: int = 7,
                         start_date: Optional[str] = None):
        """
        Plot the energy load profile.
        
        Args:
            load_data: DataFrame with load profile data
            days_to_plot: Number of days to plot
            start_date: Start date for plotting (YYYY-MM-DD format)
        """
        if start_date:
            start_dt = pd.to_datetime(start_date)
            end_dt = start_dt + timedelta(days=days_to_plot)
            plot_data = load_data.loc[start_dt:end_dt]
        else:
            plot_data = load_data.head(days_to_plot * 24 * 4)  # 4 intervals per hour
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10), sharex=True)
        
        # Plot total power consumption
        ax1.plot(plot_data.index, plot_data['total_power'], linewidth=1.5, color='blue')
        ax1.set_ylabel('Power Consumption (W)')
        ax1.set_title(f'Energy Load Profile ({days_to_plot} days)')
        ax1.grid(True, alpha=0.3)
        
        # Plot temperature
        ax2.plot(plot_data.index, plot_data['temperature'], linewidth=1.5, color='red')
        ax2.set_ylabel('Temperature (°C)')
        ax2.set_xlabel('Date and Time')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.xticks(rotation=45)
        plt.show()
    
    def export_to_csv(self, load_data: pd.DataFrame, filename: str):
        """
        Export load profile data to CSV file.
        
        Args:
            load_data: DataFrame with load profile data
            filename: Output filename
        """
        load_data.to_csv(filename)
        print(f"Load profile exported to {filename}")
    
    def get_statistics(self, load_data: pd.DataFrame) -> Dict:
        """
        Calculate statistics for the load profile.
        
        Args:
            load_data: DataFrame with load profile data
        
        Returns:
            Dictionary with statistics
        """
        stats = {
            'total_energy_kwh': load_data['total_power'].sum() * 0.25 / 1000,  # 15min intervals
            'average_power_w': load_data['total_power'].mean(),
            'max_power_w': load_data['total_power'].max(),
            'min_power_w': load_data['total_power'].min(),
            'peak_to_average_ratio': load_data['total_power'].max() / load_data['total_power'].mean(),
            'load_factor': load_data['total_power'].mean() / load_data['total_power'].max(),
            'temperature_range': {
                'min': load_data['temperature'].min(),
                'max': load_data['temperature'].max(),
                'mean': load_data['temperature'].mean()
            }
        }
        
        return stats

# Example usage and configuration
def main():
    # Initialize the generator with your WeatherAPI.com API key
    # Get a free API key from https://www.weatherapi.com/
    api_key = "your_weather_api_key_here"
    generator = EnergyLoadProfileGenerator(api_key)
    
    # Define custom device configuration (optional)
    custom_heat_pump = {
        'base_power': 3000,
        'temp_coefficient': -80,  # More sensitive to cold
        'comfort_temp': 18,
        'daily_pattern': [0.9, 0.7, 0.6, 0.5, 0.5, 0.7, 1.0, 0.9, 0.8, 0.7, 0.7, 0.8, 0.9, 0.9, 1.0, 1.1, 1.3, 1.4, 1.3, 1.2, 1.1, 1.0, 0.9, 0.9],
        'seasonal_factor': [1.5, 1.3, 1.0, 0.8, 0.6, 0.5, 0.5, 0.6, 0.8, 1.0, 1.2, 1.4]  # Monthly factors
    }
    
    generator.add_device_config('heat_pump', custom_heat_pump)
    
    # Fetch weather data for a specific location and time period
    location = "Berlin, Germany"  # Can also use coordinates: "52.5200,13.4050"
    start_date = "2024-01-01"
    end_date = "2024-01-31"  # One month for demonstration
    
    print("Fetching weather data...")
    weather_data = generator.get_weather_data(location, start_date, end_date)
    
    # Define devices and their quantities
    devices = ['heat_pump', 'general_load', 'refrigeration']
    quantities = {'heat_pump': 1, 'general_load': 2, 'refrigeration': 1}
    
    # Generate load profile
    print("Generating load profile...")
    load_profile = generator.generate_load_profile(devices, weather_data, quantities)
    
    # Calculate and display statistics
    stats = generator.get_statistics(load_profile)
    print("\nLoad Profile Statistics:")
    print(f"Total Energy Consumption: {stats['total_energy_kwh']:.2f} kWh")
    print(f"Average Power: {stats['average_power_w']:.2f} W")
    print(f"Maximum Power: {stats['max_power_w']:.2f} W")
    print(f"Load Factor: {stats['load_factor']:.3f}")
    print(f"Temperature Range: {stats['temperature_range']['min']:.1f}°C to {stats['temperature_range']['max']:.1f}°C")
    
    # Plot the results
    generator.plot_load_profile(load_profile, days_to_plot=7)
    
    # Export to CSV
    generator.export_to_csv(load_profile, 'energy_load_profile.csv')

if __name__ == "__main__":
    main()