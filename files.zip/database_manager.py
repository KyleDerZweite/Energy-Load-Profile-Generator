#!/usr/bin/env python3
"""
Standalone script to manage the weather database.
"""

from weather_database import WeatherDatabase
import argparse
import sys
from datetime import datetime

def main():
    parser = argparse.ArgumentParser(description='Weather Database Manager')
    parser.add_argument('--db', default='weather_data.db', help='Database file path')
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all locations')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show database statistics')
    
    # Check command
    check_parser = subparsers.add_parser('check', help='Check data availability')
    check_parser.add_argument('location', help='Location name')
    check_parser.add_argument('start_date', help='Start date (YYYY-MM-DD)')
    check_parser.add_argument('end_date', help='End date (YYYY-MM-DD)')
    
    # Delete command
    delete_parser = subparsers.add_parser('delete', help='Delete location data')
    delete_parser.add_argument('location', help='Location name to delete')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Initialize database
    db = WeatherDatabase(args.db)
    
    if args.command == 'list':
        locations = db.list_locations()
        if locations.empty:
            print("No locations found in database.")
        else:
            print("Stored locations:")
            print(locations.to_string(index=False))
    
    elif args.command == 'stats':
        stats = db.get_database_stats()
        print("Database Statistics:")
        print(f"  Total records: {stats['total_weather_records']:,}")
        print(f"  Total locations: {stats['total_locations']}")
        print(f"  Database size: {stats['database_size_mb']:.2f} MB")
        if stats['earliest_date']:
            print(f"  Date range: {stats['earliest_date']} to {stats['latest_date']}")
    
    elif args.command == 'check':
        availability = db.check_data_availability(args.location, args.start_date, args.end_date)
        print(f"Data availability for {args.location} ({args.start_date} to {args.end_date}):")
        print(f"  Location exists: {availability['location_exists']}")
        if availability['location_exists']:
            print(f"  Coverage: {availability['coverage']:.1%}")
            print(f"  Available records: {availability['available_records']:,}")
            print(f"  Expected records: {availability['expected_records']:,}")
            print(f"  Available range: {availability['available_range']}")
    
    elif args.command == 'delete':
        confirm = input(f"Are you sure you want to delete all data for '{args.location}'? (y/N): ")
        if confirm.lower() == 'y':
            db.delete_location_data(args.location)
        else:
            print("Deletion cancelled.")

if __name__ == '__main__':
    main()