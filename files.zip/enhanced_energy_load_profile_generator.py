import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json
from typing import Dict, List, Optional
import math
from weather_database import WeatherDatabase

class EnhancedEnergyLoadProfileGenerator:
    """
    Enhanced energy consumption load profile generator with local weather database caching.
    """
    
    def __init__(self, weather_api_key: str, db_path: str = "weather_data.db"):
        """
        Initialize the enhanced load profile generator.
        
        Args:
            weather_api_key: API key for WeatherAPI.com
            db_path: Path to the SQLite weather database
        """
        self.weather_api_key = weather_api_key
        self.base_url = "http://api.weatherapi.com/v1"
        self.weather_db = WeatherDatabase(db_path)
        
        # Default device configurations (same as original)
        self.device_configs = {
            'heater': {
                'base_power': 2000,
                'temp_coefficient': -50,
                'comfort_temp': 20,
                'daily_pattern': [0.8, 0.6, 0.5, 0.4, 0.4, 0.6, 1.0, 0.9, 0.7, 0.6, 0.6, 0.7, 0.8, 0.8, 0.9, 1.0, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.8],
                'seasonal_factor': 1.0
            },
            'air_conditioner': {
                'base_power': 1500,
                'temp_coefficient': 80,
                'comfort_temp': 22,
                'daily_pattern': [0.3, 0.2, 0.2, 0.2, 0.2, 0.3, 0.4, 0.5, 0.7, 0.9, 1.1, 1.3, 1.4, 1.3, 1.2, 1.1, 1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3],
                'seasonal_factor': 1.0
            },
            'refrigeration': {
                'base_power': 800,
                'temp_coefficient': 15,
                'comfort_temp': 15,
                'daily_pattern': [0.9, 0.8, 0.8, 0.8, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.2, 1.1, 1.0, 1.0, 1.1, 1.2, 1.3, 1.2, 1.1, 1.0, 0.9, 0.9, 0.9, 0.9],
                'seasonal_factor': 1.0
            },
            'general_load': {
                'base_power': 1000,
                'temp_coefficient': 0,
                'comfort_temp': 20,
                'daily_pattern': [0.4, 0.3, 0.3, 0.3, 0.3, 0.4, 0.8, 1.0, 0.9, 0.8, 0.8, 0.9, 1.0, 0.9, 0.8, 0.9, 1.2, 1.4, 1.3, 1.1, 0.9, 0.7, 0.6, 0.5],
                'seasonal_factor': 1.0
            }
        }
    
    def get_weather_data(self, location: str, start_date: str, end_date: str, 
                        force_api_call: bool = False) -> pd.DataFrame:
        """
        Get weather data from local database or API.
        
        Args:
            location: City name or coordinates
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            force_api_call: Force API call even if data exists locally
        
        Returns:
            DataFrame with temperature data at 15-minute intervals
        """
        # Check if data exists locally (unless forced API call)
        if not force_api_call:
            print(f"Checking local database for {location} ({start_date} to {end_date})...")
            
            availability = self.weather_db.check_data_availability(location, start_date, end_date)
            
            if availability['location_exists'] and availability['coverage'] > 0.95:
                print(f"Found {availability['available_records']} records locally (Coverage: {availability['coverage']:.1%})")
                weather_data = self.weather_db.get_weather_data(location, start_date, end_date)
                
                if weather_data is not None and not weather_data.empty:
                    return weather_data
            else:
                print(f"Local coverage: {availability['coverage']:.1%} - fetching from API...")
        
        # Fetch from API
        print(f"Fetching weather data from API for {location}...")
        weather_data = self._fetch_from_api(location, start_date, end_date)
        
        # Store in database
        if not weather_data.empty:
            self.weather_db.store_weather_data(location, weather_data)
        
        return weather_data
    
    def _fetch_from_api(self, location: str, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Fetch weather data from WeatherAPI.com
        
        Args:
            location: City name or coordinates
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
        
        Returns:
            DataFrame with weather data
        """
        weather_data = []
        current_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_dt = datetime.strptime(end_date, '%Y-%m-%d')
        
        while current_date <= end_dt:
            url = f"{self.base_url}/history.json"
            params = {
                'key': self.weather_api_key,
                'q': location,
                'dt': current_date.strftime('%Y-%m-%d')
            }
            
            try:
                response = requests.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                
                for hour_data in data['forecast']['forecastday'][0]['hour']:
                    weather_data.append({
                        'datetime': pd.to_datetime(hour_data['time']),
                        'temperature': hour_data['temp_c'],
                        'humidity': hour_data['humidity'],
                        'condition': hour_data['condition']['text']
                    })
                    
            except requests.exceptions.RequestException as e:
                print(f"Error fetching weather data for {current_date}: {e}")
                # Fill with average temperature if API fails
                for hour in range(24):
                    weather_data.append({
                        'datetime': current_date.replace(hour=hour),
                        'temperature': 15.0,
                        'humidity': 50,
                        'condition': 'Unknown'
                    })
            
            current_date += timedelta(days=1)
        
        if not weather_data:
            return pd.DataFrame()
        
        df = pd.DataFrame(weather_data)
        df.set_index('datetime', inplace=True)
        
        # Interpolate to 15-minute intervals
        df_15min = df.resample('15T').interpolate(method='linear')
        
        return df_15min
    
    def add_device_config(self, device_name: str, config: Dict):
        """Add or update a device configuration."""
        required_keys = ['base_power', 'temp_coefficient', 'comfort_temp', 'daily_pattern']
        if not all(key in config for key in required_keys):
            raise ValueError(f"Device config must contain: {required_keys}")
        
        if len(config['daily_pattern']) != 24:
            raise ValueError("Daily pattern must have 24 hourly values")
        
        self.device_configs[device_name] = config
    
    def calculate_device_load(self, device_name: str, temperature: float, 
                            hour_of_day: int, day_of_year: int) -> float:
        """Calculate power consumption for a specific device."""
        if device_name not in self.device_configs:
            raise ValueError(f"Device '{device_name}' not configured")
        
        config = self.device_configs[device_name]
        
        # Base power consumption
        base_power = config['base_power']
        
        # Temperature influence
        temp_diff = temperature - config['comfort_temp']
        temp_factor = 1 + (temp_diff * config['temp_coefficient'] / base_power)
        temp_factor = max(0.1, temp_factor)
        
        # Daily pattern influence
        daily_factor = config['daily_pattern'][hour_of_day]
        
        # Seasonal influence
        seasonal_factor = config.get('seasonal_factor', 1.0)
        if isinstance(seasonal_factor, (list, tuple)):
            season_index = (day_of_year - 1) * len(seasonal_factor) / 365
            seasonal_factor = np.interp(season_index, range(len(seasonal_factor)), seasonal_factor)
        
        # Add random variation
        random_factor = 1 + np.random.normal(0, 0.05)
        
        total_power = base_power * temp_factor * daily_factor * seasonal_factor * random_factor
        
        return max(0, total_power)
    
    def generate_load_profile(self, devices: List[str], weather_data: pd.DataFrame,
                            quantities: Optional[Dict[str, int]] = None) -> pd.DataFrame:
        """Generate combined load profile for multiple devices."""
        if quantities is None:
            quantities = {device: 1 for device in devices}
        
        load_data = []
        
        for idx, (timestamp, row) in enumerate(weather_data.iterrows()):
            temperature = row['temperature']
            hour_of_day = timestamp.hour
            day_of_year = timestamp.timetuple().tm_yday
            
            total_power = 0
            device_powers = {}
            
            for device in devices:
                device_quantity = quantities.get(device, 1)
                device_power = self.calculate_device_load(
                    device, temperature, hour_of_day, day_of_year
                ) * device_quantity
                
                device_powers[f'{device}_power'] = device_power
                total_power += device_power
            
            load_entry = {
                'datetime': timestamp,
                'temperature': temperature,
                'total_power': total_power,
                'hour_of_day': hour_of_day,
                'day_of_year': day_of_year
            }
            load_entry.update(device_powers)
            load_data.append(load_entry)
        
        df = pd.DataFrame(load_data)
        df.set_index('datetime', inplace=True)
        
        return df
    
    def show_database_info(self):
        """Display information about the weather database."""
        print("\n=== Weather Database Information ===")
        
        # Database statistics
        stats = self.weather_db.get_database_stats()
        print(f"Total weather records: {stats['total_weather_records']:,}")
        print(f"Total locations: {stats['total_locations']}")
        print(f"Database size: {stats['database_size_mb']:.2f} MB")
        if stats['earliest_date'] and stats['latest_date']:
            print(f"Date range: {stats['earliest_date']} to {stats['latest_date']}")
        
        # List locations
        locations_df = self.weather_db.list_locations()
        if not locations_df.empty:
            print(f"\nStored locations:")
            print(locations_df.to_string(index=False))
        else:
            print("\nNo locations stored yet.")
    
    def plot_load_profile(self, load_data: pd.DataFrame, days_to_plot: int = 7,
                         start_date: Optional[str] = None):
        """Plot the energy load profile."""
        if start_date:
            start_dt = pd.to_datetime(start_date)
            end_dt = start_dt + timedelta(days=days_to_plot)
            plot_data = load_data.loc[start_dt:end_dt]
        else:
            plot_data = load_data.head(days_to_plot * 24 * 4)
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10), sharex=True)
        
        # Plot total power consumption
        ax1.plot(plot_data.index, plot_data['total_power'], linewidth=1.5, color='blue')
        ax1.set_ylabel('Power Consumption (W)')
        ax1.set_title(f'Energy Load Profile ({days_to_plot} days)')
        ax1.grid(True, alpha=0.3)
        
        # Plot temperature
        ax2.plot(plot_data.index, plot_data['temperature'], linewidth=1.5, color='red')
        ax2.set_ylabel('Temperature (°C)')
        ax2.set_xlabel('Date and Time')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.xticks(rotation=45)
        plt.show()
    
    def export_to_csv(self, load_data: pd.DataFrame, filename: str):
        """Export load profile data to CSV file."""
        load_data.to_csv(filename)
        print(f"Load profile exported to {filename}")
    
    def get_statistics(self, load_data: pd.DataFrame) -> Dict:
        """Calculate statistics for the load profile."""
        stats = {
            'total_energy_kwh': load_data['total_power'].sum() * 0.25 / 1000,
            'average_power_w': load_data['total_power'].mean(),
            'max_power_w': load_data['total_power'].max(),
            'min_power_w': load_data['total_power'].min(),
            'peak_to_average_ratio': load_data['total_power'].max() / load_data['total_power'].mean(),
            'load_factor': load_data['total_power'].mean() / load_data['total_power'].max(),
            'temperature_range': {
                'min': load_data['temperature'].min(),
                'max': load_data['temperature'].max(),
                'mean': load_data['temperature'].mean()
            }
        }
        
        return stats

# Example usage with database caching
def main():
    # Initialize the enhanced generator
    api_key = "your_weather_api_key_here"
    generator = EnhancedEnergyLoadProfileGenerator(api_key, "weather_cache.db")
    
    # Show current database status
    generator.show_database_info()
    
    # Parameters
    location = "Berlin, Germany"
    start_date = "2024-01-01"
    end_date = "2024-01-31"
    
    # First call will fetch from API and cache
    print("\n=== First run (will cache data) ===")
    weather_data = generator.get_weather_data(location, start_date, end_date)
    
    # Second call will use cached data
    print("\n=== Second run (will use cache) ===")
    weather_data = generator.get_weather_data(location, start_date, end_date)
    
    # Generate load profile
    devices = ['heater', 'general_load', 'refrigeration']
    quantities = {'heater': 1, 'general_load': 2, 'refrigeration': 1}
    
    load_profile = generator.generate_load_profile(devices, weather_data, quantities)
    
    # Display results
    stats = generator.get_statistics(load_profile)
    print(f"\nTotal Energy Consumption: {stats['total_energy_kwh']:.2f} kWh")
    print(f"Average Power: {stats['average_power_w']:.2f} W")
    
    # Show final database status
    generator.show_database_info()

if __name__ == "__main__":
    main()