#!/bin/bash
# Quick setup script for German weather database initialization

echo "=== German Weather Database Initialization Setup ==="
echo

# Check if required files exist
if [ ! -f "enhanced_energy_load_profile_generator.py" ]; then
    echo "Error: enhanced_energy_load_profile_generator.py not found!"
    echo "Please ensure all required files are in the current directory."
    exit 1
fi

if [ ! -f "weather_database.py" ]; then
    echo "Error: weather_database.py not found!"
    exit 1
fi

# Install requirements if not already installed
echo "Installing Python dependencies..."
pip install requests pandas numpy matplotlib sqlite3 > /dev/null 2>&1

# Check if API key is provided as argument
if [ -z "$1" ]; then
    echo "Usage: $0 <weather_api_key> [priority|all] [start_date] [end_date]"
    echo
    echo "Examples:"
    echo "  $0 your_api_key_here priority"
    echo "  $0 your_api_key_here all 2024-01-01 2024-03-31"
    echo
    echo "Get a free API key from: https://www.weatherapi.com/"
    exit 1
fi

API_KEY="$1"
MODE="${2:-priority}"
START_DATE="${3:-$(date -d '90 days ago' '+%Y-%m-%d')}"
END_DATE="${4:-$(date -d '1 day ago' '+%Y-%m-%d')}"

echo "Configuration:"
echo "  API Key: ${API_KEY:0:10}..."
echo "  Mode: $MODE"
echo "  Start Date: $START_DATE"
echo "  End Date: $END_DATE"
echo

# Run the initialization
if [ "$MODE" = "priority" ]; then
    python3 germany_weather_db_initializer.py \
        --api-key "$API_KEY" \
        --start-date "$START_DATE" \
        --end-date "$END_DATE" \
        --priority-only \
        --delay 1.0
else
    python3 germany_weather_db_initializer.py \
        --api-key "$API_KEY" \
        --start-date "$START_DATE" \
        --end-date "$END_DATE" \
        --delay 1.0
fi

echo
echo "Initialization complete! Database saved as 'germany_weather.db'"